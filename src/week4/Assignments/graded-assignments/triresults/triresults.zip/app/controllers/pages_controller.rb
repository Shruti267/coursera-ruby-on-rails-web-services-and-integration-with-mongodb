class PagesController < ApplicationController
	


	def index
		#nothing there
		render plain: "index"
	end
end