require 'test_helper'

class AddressComponentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
